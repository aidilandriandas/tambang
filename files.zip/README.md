# NOC Tambang – dashboard monitoring (Zabbix)

Dashboard satu web yang mengambil data dari **Zabbix** lewat API. Jika backend atau Zabbix tidak terjangkau, halaman memakai data demo.

## Install di VM baru
Salin folder ini ke VM (Ubuntu/Debian), lalu `sudo bash install.sh`. Script memasang Python, nginx, service systemd, dan login web, lalu menampilkan alamat akses.
Tanpa pertanyaan: `sudo ZABBIX_URL=http://10.10.0.50/zabbix ZABBIX_TOKEN=xxx WEB_USER=admin WEB_PASS=rahasia bash install.sh`
Ubah konfigurasi: edit `/etc/noc-tambang.env`, lalu `sudo systemctl restart noc-tambang`.

## Persiapan di Zabbix
1. Buat user khusus (mis. `noc-dashboard`) dengan hak **baca** ke host group perangkat jaringan.
2. Buat **API token** untuk user itu (Users → API tokens, atau Administration → General → API tokens).
3. `ZABBIX_URL` adalah alamat web Zabbix, mis. `http://10.10.0.50/zabbix` (sertakan `/zabbix` bila ada). Zabbix di bawah 6.4: tambahkan `ZABBIX_LEGACY_AUTH=1` di `/etc/noc-tambang.env`.
4. **Site** di peta = isi *Inventory → Location* host. Jika kosong, dipakai nama host group pertama. Aktifkan inventory host (mode manual) dan isi location per perangkat.
5. **Garis link** diambil dari **Network Map** Zabbix (hubungkan dua host dengan link) atau dari file `/var/lib/noc-tambang/links.json` berisi pasangan nama host: `[["ptp-ktr-twa","ptp-twa-ktr"]]`. Hanya link yang kedua ujungnya punya item sinyal yang digambar.
6. **Item sinyal** dikenali dari nama atau key yang mengandung `signal`/`rssi`, `snr`, `noise`, `temp`. Template radio Anda mungkin memakai istilah lain; ubah dengan `ZBX_RSSI_RE`, `ZBX_SNR_RE`, `ZBX_NOISE_RE`, `ZBX_TEMP_RE` di file env (regex).
7. Status: **Down** bila interface Zabbix berstatus unavailable atau ICMP ping gagal; **Peringatan** bila ada trigger aktif berseverity Warning ke atas (ubah dengan `ZBX_MIN_SEVERITY`) atau packet loss di atas 2%. Latency dan loss butuh item `icmpping`, `icmppingsec`, `icmppingloss` (template ICMP Ping).

## Cek IP terpakai / kosong
Di tab IPAM, klik subnet untuk melihat peta tiap IP. IP terpakai diambil dari IP interface semua host Zabbix. Reservasi manual disimpan di `data/reserved.json`. Perangkat yang tidak ada di Zabbix tidak terdeteksi, jadi reservasikan manual.

## Keamanan
Endpoint IPAM tidak punya login sendiri; nginx basic auth dari `install.sh` yang melindunginya. Jangan buka ke internet tanpa VPN.
