# NOC Tambang – dashboard monitoring

Dashboard satu web yang mengambil data dari **LibreNMS**. Jika backend tidak terjangkau, halaman otomatis memakai data demo.

## Menjalankan
1. Di LibreNMS: *Settings → API → Create API access token* (cukup akses baca).
2. Di server yang bisa menjangkau LibreNMS:
```
cd noc-tambang
python3 -m venv venv && . venv/bin/activate
pip install -r requirements.txt
export LIBRENMS_URL=http://10.10.0.50 LIBRENMS_TOKEN=xxxx
gunicorn -b 0.0.0.0:8080 server:app
```
3. Buka `http://IP-SERVER:8080`.

## Penyesuaian di LibreNMS agar data lengkap
- Isi **location** tiap perangkat (mis. "Tower Hilltop A", "Pit 1"). Location menjadi "site" di peta.
- Aktifkan **LLDP/CDP** atau tambahkan link manual, supaya garis antar site muncul. Hanya link yang punya sensor sinyal (wireless) yang digambar.
- Sensor sinyal dibaca dari class `signal`, `snr`, `noise-floor`. Ubiquiti, Cambium, dan MikroTik umumnya sudah terdeteksi otomatis. Cek di halaman device → Health/Wireless.
- Alert memakai *alert rules* LibreNMS (mis. `signal < -72`). Perangkat dengan alert aktif tampil kuning.
- Packet loss belum diambil (kolom tampil 0%); latency memakai hasil ping terakhir.

## Cek IP terpakai / kosong
Di tab IPAM, klik subnet untuk melihat peta tiap IP (biru = terpakai, kuning = reservasi, kosong = tersedia). IP terpakai diambil dari IP management perangkat dan IP interface di LibreNMS. Reservasi manual disimpan di `data/reserved.json`. IP yang dipakai perangkat non-SNMP (mis. laptop, kamera yang tidak ditambahkan ke LibreNMS) tidak terdeteksi, jadi reservasikan manual bila perlu.

## Keamanan
IPAM tersimpan di `data/ipam.json` dan endpoint tambah subnet tidak memakai login. Letakkan di belakang nginx basic auth atau VPN, jangan dibuka ke internet.
