"""Backend NOC Tambang: mengambil data dari LibreNMS dan menyajikannya ke dashboard."""
import os, re, json, html, time, threading
import requests
from flask import Flask, jsonify, request

BASE = os.environ.get("LIBRENMS_URL", "").rstrip("/")
TOKEN = os.environ.get("LIBRENMS_TOKEN", "")
VERIFY = os.environ.get("LIBRENMS_VERIFY_TLS", "1") == "1"
IPAM_FILE = os.environ.get("IPAM_FILE", "data/ipam.json")
RES_FILE = os.path.join(os.path.dirname(IPAM_FILE) or ".", "reserved.json")
TTL = 15  # detik cache, supaya LibreNMS tidak dibebani banyak klien

app = Flask(__name__, static_folder="static", static_url_path="")
_cache = {"t": 0, "v": None}
_lock = threading.Lock()


def api(path):
    if not BASE or not TOKEN:
        raise RuntimeError("LibreNMS belum dikonfigurasi")
    r = requests.get(f"{BASE}/api/v0/{path}", headers={"X-Auth-Token": TOKEN},
                     timeout=15, verify=VERIFY)
    r.raise_for_status()
    return r.json()


def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-") or "tanpa-lokasi"


def vals(sensors, did, cls):
    return [x for x in sensors.get(did, {}).get(cls, []) if x is not None]


def build():
    devs = api("devices").get("devices", [])
    sens = api("resources/sensors").get("sensors", [])
    alerts = api("alerts?state=1").get("alerts", [])
    try:
        links = api("resources/links").get("links", [])
    except Exception:
        links = []

    alert_dev = {a["device_id"] for a in alerts}
    by = {}
    for s in sens:
        by.setdefault(s["device_id"], {}).setdefault(s["sensor_class"], []).append(s.get("sensor_current"))

    sites, dev_site, out = {}, {}, []
    for d in devs:
        if d.get("disabled") or d.get("ignore"):
            continue
        loc = (d.get("location") or "Tanpa lokasi").strip()
        k = slug(loc)
        sites[k] = html.escape(loc)
        dev_site[d["device_id"]] = k
        temps = vals(by, d["device_id"], "temperature")
        up = d.get("status") == 1
        out.append({
            "name": html.escape(d.get("sysName") or d["hostname"]),
            "ip": html.escape(str(d.get("ip") or d["hostname"])),
            "loc": k, "type": html.escape(d.get("os") or "-"),
            "st": "down" if not up else ("warn" if d["device_id"] in alert_dev else "up"),
            "lat": round(d.get("last_ping_timetaken") or 0), "loss": 0,
            "temp": round(max(temps)) if temps else 0,
            "up": int((d.get("uptime") or 0) // 3600),
        })

    seen = {}
    for l in links:
        a, b = l.get("local_device_id"), l.get("remote_device_id")
        if a not in dev_site or b not in dev_site or dev_site[a] == dev_site[b]:
            continue
        sig = vals(by, a, "signal") + vals(by, b, "signal")
        if not sig:
            continue  # hanya link wireless (punya sensor sinyal) yang ditampilkan
        rssi = round(min(sig))
        snr = vals(by, a, "snr") + vals(by, b, "snr")
        noise = vals(by, a, "noise-floor") + vals(by, b, "noise-floor")
        s = round(min(snr)) if snr else (round(rssi - max(noise)) if noise else 30)
        key = tuple(sorted((dev_site[a], dev_site[b])))
        if key not in seen or rssi < seen[key][2]:
            seen[key] = [key[0], key[1], rssi, s, "Wireless · –"]

    ips = {}
    for d in devs:
        if d.get("ip"):
            ips[str(d["ip"])] = {"n": html.escape(d.get("sysName") or d["hostname"]), "t": "dev"}
    try:
        for a in api("resources/ip/addresses").get("ip_addresses", []):
            ip = a.get("ipv4_address")
            if ip and ip not in ips:
                ips[ip] = {"n": "Interface perangkat (LibreNMS)", "t": "if"}
    except Exception:
        pass

    return {"devices": out, "sites": sites, "links": list(seen.values()), "ipam": load_ipam(), "ips": ips}


def load_ipam():
    try:
        with open(IPAM_FILE) as f:
            return json.load(f)
    except Exception:
        return []


@app.get("/api/summary")
def summary():
    with _lock:
        if time.time() - _cache["t"] > TTL:
            try:
                _cache.update(t=time.time(), v=build())
            except Exception as e:
                return jsonify(error=str(e)), 502
        v = dict(_cache["v"])
        v["ipam"] = load_ipam()
        v["ips"] = {**v["ips"], **load_res()}
        return jsonify(v)


def load_res():
    try:
        with open(RES_FILE) as f:
            return json.load(f)
    except Exception:
        return {}


def save_res(r):
    os.makedirs(os.path.dirname(RES_FILE) or ".", exist_ok=True)
    with open(RES_FILE, "w") as f:
        json.dump(r, f)
    _cache["t"] = 0


@app.post("/api/ips")
def res_add():
    j = request.get_json(force=True)
    ip = str(j.get("ip", ""))
    if not re.fullmatch(r"\d{1,3}(\.\d{1,3}){3}", ip):
        return jsonify(error="IP tidak valid"), 400
    r = load_res()
    r[ip] = {"n": html.escape(str(j.get("note") or "Reservasi"))[:80], "t": "res"}
    save_res(r)
    return jsonify(ok=True)


@app.delete("/api/ips")
def res_del():
    ip = str(request.get_json(force=True).get("ip", ""))
    r = load_res()
    r.pop(ip, None)
    save_res(r)
    return jsonify(ok=True)


@app.post("/api/ipam")
def add_ipam():
    row = request.get_json(force=True)
    if not isinstance(row, list) or len(row) != 6:
        return jsonify(error="format salah"), 400
    rows = load_ipam()
    rows.append([html.escape(str(x)) if isinstance(x, str) else x for x in row])
    os.makedirs(os.path.dirname(IPAM_FILE) or ".", exist_ok=True)
    with open(IPAM_FILE, "w") as f:
        json.dump(rows, f)
    return jsonify(ok=True)


@app.get("/")
def index():
    return app.send_static_file("index.html")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
