"""Backend NOC Tambang untuk Zabbix (JSON-RPC API). Dibaca oleh dashboard di static/index.html."""
import os, re, json, html, time, threading, itertools
import requests
from flask import Flask, jsonify, request

URL = os.environ.get("ZABBIX_URL", "").rstrip("/")
if URL and not URL.endswith(".php"):
    URL += "/api_jsonrpc.php"
TOKEN = os.environ.get("ZABBIX_TOKEN", "")
VERIFY = os.environ.get("ZABBIX_VERIFY_TLS", "1") == "1"
LEGACY = os.environ.get("ZABBIX_LEGACY_AUTH", "0") == "1"  # isi 1 bila Zabbix di bawah 6.4
MIN_SEV = int(os.environ.get("ZBX_MIN_SEVERITY", "2"))      # 2 = Warning ke atas dianggap alert
IPAM_FILE = os.environ.get("IPAM_FILE", "data/ipam.json")
DATA_DIR = os.path.dirname(IPAM_FILE) or "."
RES_FILE = os.path.join(DATA_DIR, "reserved.json")
LINKS_FILE = os.environ.get("LINKS_FILE", os.path.join(DATA_DIR, "links.json"))
# Pola nama/key item di Zabbix yang dianggap sinyal. Sesuaikan dengan template radio Anda.
RSSI_RE = re.compile(os.environ.get("ZBX_RSSI_RE", r"rssi|signal"), re.I)
SNR_RE = re.compile(os.environ.get("ZBX_SNR_RE", r"snr|signal.?to.?noise"), re.I)
NOISE_RE = re.compile(os.environ.get("ZBX_NOISE_RE", r"noise"), re.I)
TEMP_RE = re.compile(os.environ.get("ZBX_TEMP_RE", r"temp"), re.I)
TTL = 15

app = Flask(__name__, static_folder="static", static_url_path="")
_cache = {"t": 0, "v": None}
_lock = threading.Lock()
_ids = itertools.count(1)


def rpc(method, **params):
    if not URL or not TOKEN:
        raise RuntimeError("Zabbix belum dikonfigurasi")
    body = {"jsonrpc": "2.0", "method": method, "params": params, "id": next(_ids)}
    headers = {"Content-Type": "application/json-rpc"}
    if LEGACY:
        body["auth"] = TOKEN
    else:
        headers["Authorization"] = "Bearer " + TOKEN
    r = requests.post(URL, json=body, headers=headers, timeout=20, verify=VERIFY)
    r.raise_for_status()
    j = r.json()
    if "error" in j:
        raise RuntimeError(j["error"].get("data") or j["error"].get("message"))
    return j["result"]


def jload(path, default):
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return default


def jsave(path, data):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f)


def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-") or "tanpa-lokasi"


def build():
    q = dict(output=["hostid", "host", "name"], filter={"status": 0},
             selectInterfaces=["ip", "available"], selectInventory=["location", "type"],
             selectParentTemplates=["name"])
    try:
        hosts = rpc("host.get", selectHostGroups=["name"], **q)
    except RuntimeError:  # Zabbix lama (sebelum 6.2)
        hosts = rpc("host.get", selectGroups=["name"], **q)
    ids = [h["hostid"] for h in hosts]
    if not ids:
        return {"devices": [], "sites": {}, "links": [], "ipam": [], "ips": {}, "source": "Zabbix"}

    items = {}
    for pat in ({"key_": ["icmpping", "uptime", "temp", "signal", "rssi", "snr", "noise"]},
                {"name": ["signal", "rssi", "snr", "noise", "temperature", "uptime"]}):
        for it in rpc("item.get", output=["itemid", "hostid", "key_", "name", "lastvalue"],
                      hostids=ids, monitored=True, search=pat, searchByAny=True):
            items[it["itemid"]] = it

    M = {}
    for it in items.values():
        try:
            v = float(it["lastvalue"])
        except (ValueError, TypeError):
            continue
        m = M.setdefault(it["hostid"], {"ping": None, "ms": None, "loss": None, "up": None,
                                        "temp": [], "rssi": [], "snr": [], "noise": []})
        k = it["key_"].lower()
        txt = k + " " + it["name"].lower()
        if k.startswith("icmppingsec"):
            m["ms"] = v * 1000
        elif k.startswith("icmppingloss"):
            m["loss"] = v
        elif k.startswith("icmpping"):
            m["ping"] = v
        elif "uptime" in txt:
            m["up"] = v
        elif SNR_RE.search(txt):
            m["snr"].append(v)
        elif NOISE_RE.search(txt):
            m["noise"].append(v)
        elif TEMP_RE.search(txt):
            m["temp"].append(v)
        elif RSSI_RE.search(txt) and v < 0:
            m["rssi"].append(v)

    warn = set()
    for t in rpc("trigger.get", output=["triggerid"], only_true=True, monitored=True,
                 skipDependent=True, min_severity=MIN_SEV, selectHosts=["hostid"]):
        warn.update(h["hostid"] for h in t.get("hosts", []))

    sites, host_site, by_name, out, ips = {}, {}, {}, [], {}
    for h in hosts:
        m = M.get(h["hostid"], {})
        ifs = h.get("interfaces") or []
        ip = next((i["ip"] for i in ifs if i.get("ip")), h["host"])
        inv = h.get("inventory") if isinstance(h.get("inventory"), dict) else {}
        grp = [g["name"] for g in (h.get("hostgroups") or h.get("groups") or [])]
        loc = (inv.get("location") or "").strip() or (grp[0] if grp else "Tanpa lokasi")
        k = slug(loc)
        sites[k] = html.escape(loc)
        host_site[h["hostid"]] = k
        by_name[h["host"]] = by_name[h["name"]] = h["hostid"]
        tpl = (h.get("parentTemplates") or [{}])[0].get("name", "")
        name = html.escape(h["name"] or h["host"])
        loss = m.get("loss") or 0
        down = any(i.get("available") == "2" for i in ifs) or m.get("ping") == 0
        st = "down" if down else ("warn" if h["hostid"] in warn or loss > 2 else "up")
        out.append({"name": name, "ip": html.escape(ip), "loc": k,
                    "type": html.escape(inv.get("type") or tpl or "-"), "st": st,
                    "lat": round(m.get("ms") or 0), "loss": round(loss),
                    "temp": round(max(m["temp"])) if m.get("temp") else 0,
                    "up": int((m.get("up") or 0) // 3600)})
        for i in ifs:
            if i.get("ip"):
                ips[i["ip"]] = {"n": name, "t": "dev"}

    # Link antar host: dari Network Map Zabbix dan dari links.json (pasangan nama host)
    pairs = set()
    try:
        for mp in rpc("map.get", output=["sysmapid"], selectSelements=["selementid", "elements", "elementtype"],
                      selectLinks=["selementid1", "selementid2"]):
            el = {s["selementid"]: s["elements"][0].get("hostid") for s in mp.get("selements", [])
                  if s.get("elementtype") == "0" and s.get("elements")}
            for l in mp.get("links", []):
                a, b = el.get(l["selementid1"]), el.get(l["selementid2"])
                if a and b:
                    pairs.add((a, b))
    except Exception:
        pass
    for a, b in jload(LINKS_FILE, []):
        if a in by_name and b in by_name:
            pairs.add((by_name[a], by_name[b]))

    seen = {}
    for a, b in pairs:
        if a not in host_site or b not in host_site or host_site[a] == host_site[b]:
            continue
        ma, mb = M.get(a, {}), M.get(b, {})
        sig = ma.get("rssi", []) + mb.get("rssi", [])
        if not sig:
            continue  # hanya link yang punya data sinyal yang digambar
        rssi = round(min(sig))
        snr = ma.get("snr", []) + mb.get("snr", [])
        noise = ma.get("noise", []) + mb.get("noise", [])
        s = round(min(snr)) if snr else (round(rssi - max(noise)) if noise else 30)
        key = tuple(sorted((host_site[a], host_site[b])))
        if key not in seen or rssi < seen[key][2]:
            seen[key] = [key[0], key[1], rssi, s, "Wireless · –"]

    return {"devices": out, "sites": sites, "links": list(seen.values()),
            "ipam": jload(IPAM_FILE, []), "ips": ips, "source": "Zabbix"}


@app.get("/api/summary")
def summary():
    with _lock:
        if time.time() - _cache["t"] > TTL or _cache["v"] is None:
            try:
                _cache.update(t=time.time(), v=build())
            except Exception as e:
                return jsonify(error=str(e)), 502
        v = dict(_cache["v"])
        v["ipam"] = jload(IPAM_FILE, [])
        v["ips"] = {**v["ips"], **jload(RES_FILE, {})}
        return jsonify(v)


@app.post("/api/ipam")
def add_ipam():
    row = request.get_json(force=True)
    if not isinstance(row, list) or len(row) != 6:
        return jsonify(error="format salah"), 400
    rows = jload(IPAM_FILE, [])
    rows.append([html.escape(str(x)) if isinstance(x, str) else x for x in row])
    jsave(IPAM_FILE, rows)
    return jsonify(ok=True)


@app.post("/api/ips")
def res_add():
    j = request.get_json(force=True)
    ip = str(j.get("ip", ""))
    if not re.fullmatch(r"\d{1,3}(\.\d{1,3}){3}", ip):
        return jsonify(error="IP tidak valid"), 400
    r = jload(RES_FILE, {})
    r[ip] = {"n": html.escape(str(j.get("note") or "Reservasi"))[:80], "t": "res"}
    jsave(RES_FILE, r)
    return jsonify(ok=True)


@app.delete("/api/ips")
def res_del():
    ip = str(request.get_json(force=True).get("ip", ""))
    r = jload(RES_FILE, {})
    r.pop(ip, None)
    jsave(RES_FILE, r)
    return jsonify(ok=True)


@app.get("/")
def index():
    return app.send_static_file("index.html")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
